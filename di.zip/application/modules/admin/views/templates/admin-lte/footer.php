<script src="<?php echo base_url().'templates/admin_lte/';?>plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="<?php echo base_url().'templates/admin_lte/';?>plugins/jQueryUI/jquery-ui.min.js"></script>
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<script src="<?php echo base_url().'templates/admin_lte/';?>bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo base_url().'templates/admin/'; ?>js/bootstrap-tagsinput.js"></script>


<script type="text/javascript">
	var _url = '<?php echo base_url() ?>';
</script>
<script src="<?php echo base_url().'templates/admin/'; ?>js/script.js"></script>
<script src="<?php echo base_url().'templates/admin_lte/'; ?>js/script.js"></script>

<script src="<?php echo base_url().'templates/admin_lte/';?>plugins/raphael/raphael-min.js"></script>
<script src="<?php echo base_url().'templates/admin_lte/';?>plugins/morris/morris.min.js"></script>
<script src="<?php echo base_url().'templates/admin_lte/';?>plugins/sparkline/jquery.sparkline.min.js"></script>
<script src="<?php echo base_url().'templates/admin_lte/';?>plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="<?php echo base_url().'templates/admin_lte/';?>plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<script src="<?php echo base_url().'templates/admin_lte/';?>plugins/knob/jquery.knob.js"></script>
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script> -->
<script src="<?php echo base_url().'templates/admin_lte/';?>plugins/daterangepicker/daterangepicker.js"></script>
<script src="<?php echo base_url().'templates/admin_lte/';?>plugins/datepicker/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url().'templates/admin_lte/';?>plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<script src="<?php echo base_url().'templates/admin_lte/';?>plugins/slimScroll/jquery.slimscroll.min.js"></script>
<script src="<?php echo base_url().'templates/admin_lte/';?>plugins/fastclick/fastclick.js"></script>
<script src="<?php echo base_url().'templates/admin_lte/';?>dist/js/app.min.js"></script>
<script src="<?php echo base_url().'templates/admin_lte/';?>dist/js/pages/dashboard.js"></script>
<script src="<?php echo base_url().'templates/admin_lte/';?>dist/js/demo.js"></script>