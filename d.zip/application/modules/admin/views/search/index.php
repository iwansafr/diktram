<?php
$keyword = $this->input->get('keyword');

$this->load->view('admin/content/list');