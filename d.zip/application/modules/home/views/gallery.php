<?php defined('BASEPATH') OR exit('No direct script access allowed');

$this->load->view('home/'.$active_template.'/gallery');