$(document).ready(function(){
	// $('input[type="text"]').focus();
});